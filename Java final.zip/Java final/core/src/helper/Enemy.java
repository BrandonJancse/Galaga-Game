package helper;

public class Enemy {
}
