package helper;

public class Constants {
    public static final float PPM = 32.0f;


}
